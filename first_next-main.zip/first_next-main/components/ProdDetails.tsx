import React from 'react'
import {AiFillStar, AiOutlineStar } from 'react-icons/ai';
import { Button} from '@nextui-org/react';
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import { Helmet } from 'react-helmet';
import { RichText } from '@graphcms/rich-text-react-renderer';
import styled from 'styled-components';

const ProdDetails = ({product}:{product:any},) => {
    const quantity = 0
    const responsive = {
      superLargeDesktop: {
        // the naming can be any, depends on you.
        breakpoint: { max: 4000, min: 3000 },
        items: 1
      },
      desktop: {
        breakpoint: { max: 3000, min: 1024 },
        items: 1
      },
      tablet: {
        breakpoint: { max: 1024, min: 464 },
        items: 1
      },
      mobile: {
        breakpoint: { max: 464, min: 0 },
        items: 1
      }
    }

    return (
    <>
    <Helmet>

    <title>{product[0].productTitle}</title>

    <meta name="description" content={product[0].productTitle} />

</Helmet>
    
    <div className="col-span-10 ">
        <div className="product-details-desc pt-4 grid grid-cols-1 lg:grid-cols-6">
            <div className="lg:col-start-1 lg:col-end-5 mx-8 ">
              <Carousel responsive={responsive} >
                {product[0].productImages.map((p: { url: string | undefined; }, index: any) => (
                  <img loading="lazy" src={p.url} className="pd_image" />
                ))}
              </Carousel>

            </div>
            <div className="product_view mx-2 lg:col-start-5 lg:col-end-7 flex items-center grid h-1/2">
                <h1 className="text-white font-bold">{product[0].productTitle}
                    <span className="reviews flex items-center">
                    <AiFillStar />
                    <AiFillStar />
                    <AiFillStar />
                    <AiFillStar />
                    <AiOutlineStar />
                    </span>
                    </h1>
                    <h4 className="mt-4 font-semibold text-xl">Details:</h4>
                    <span className="mt-4 font-semibold text-sm"><WrapWhiteText><RichText content={product[0].prodDescription.raw}/></WrapWhiteText></span>
                 
                    <span className="my-4 flex justify-center font-bold">${product[0].productPrice}</span>
            <div className="flex justify-center">
            
          {quantity === 0 ? (
            <button className="snipcart-add-item bg-purple-600 rounded-lg p-2 w-4/5 mt-4"
            data-item-id={product[0].slug}
            data-item-name={product[0].productTitle}
            data-item-price={product[0].productPrice}
            data-item-url={`/product/${product[0].slug}`}
            data-item-description="nice"
            data-item-image={product[0].productImage.url}
            data-item-custom1-name="Variant"
            data-item-custom1-options={product[0].prodOptions} >
              + Add To Cart
            </button>
          ) : (
            <div
              className="d-flex align-items-center flex-column"
              style={{ gap: ".5rem" }}
            >
              <div
                className="d-flex align-items-center justify-content-center"
                style={{ gap: ".5rem" }}
              >
                <Button >-</Button>
                <div>
                  <span className="fs-3">0</span> in cart
                </div>
                <Button >+</Button>
              </div>
              
            </div>
          )}
          

          
          </div>
            </div>
            
        </div>
                
                
            </div>
            

        
       
        
    </>
  )
}

export default ProdDetails

const WrapWhiteText = styled.div`


    p { color: white };
    a {color:white};
    p{font-size: 1.00rem};
    p{line-height}
`;

