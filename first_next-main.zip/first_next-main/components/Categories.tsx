import React, {useState, useEffect} from 'react';
import Link from 'next/link';

import { getCategories } from '../services';

const Categories = () => {
  const [categories, setCategories] = useState([] as any[]);

  useEffect(() => {
    getCategories()
      .then((newCategories) => setCategories(newCategories))

  },[]);


  return (
    <div className="grid grid-cols-12 h-full w-screen mb-10">
                  <div className="col-span-1"></div>
        
                    <div className="col-span-10">
                        <div className="grid grid-cols-5 gap-4">
                          {categories.map((category, index) => (
                          <div className="col-span-1 bg-black">  
                            <Link key={index} href={`/category/${category.slug}`}>
                              <div className="font-bold"> {category.name}</div>
                            </Link>
                          </div>
                          )
                        )}
                      </div>
                    </div> 
                             
                </div>
  )
}

export default Categories
