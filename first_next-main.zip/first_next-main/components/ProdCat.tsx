import React, { useEffect, useState } from 'react'
import { getProdCat } from '../services';
import Link from 'next/link';


const PC = () => {
    const [prods, setProds] = useState([] as any[]);
  
    useEffect(() => {
      getProdCat()
        .then((newProds) => setProds(newProds))
  
    },[]);

  return (
    <>
    <div className="w-full p-8" >
  <div className=" mb-8">
      <span className="text-slate-300 font-bold text-3xl sm:text-3xl hover:text-purple-600">Shop by</span>
      <span className="text-purple-600 font-bold text-3xl sm:text-4xl hover:text-purple-600"> Category</span>
    </div> 
      <div className="col-span-10" >
          <div className="grid grid-cols-1 sm:grid-cols-4 shadow-lg shadow-purple-600 rounded-b-lg" >
              {prods.map((product, index) => (
                  <div className="col-span-1  p-4 hover:shadow-lg hover:shadow-orange-100">
                  <div className="font-bold text-xl flex justify-center pb-4 hover:text-purple-600 "> {product.title}</div>              
                  <div className="flex justify-center ">
                      <Link href={`${product.image.imageProductCat[0].productLink}`} className="" >
                          <img src={product.image.imageProductCat[0].image.url}  className="h-80 w-80 rounded-lg hover:brightness-125 transition duration-500 transorm hover:-translate-y-1" alt={''} />
                      </Link>
                      </div>
                  </div>
                  )
              )}
              </div>
          </div>         
      </div>
      </>
  )
}

export default PC
