import React, { useEffect, useState } from "react";

import { getBestSelling } from "../services";
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";

interface Props {
  tags: string;
  onTagsClick: (tags: string) => void;
}

const Best: React.FC<Props> = ({ tags, onTagsClick }) => {
  const [sellings, setSelling] = useState([] as any[]);
  const responsive = {
    superLargeDesktop: {
      // the naming can be any, depends on you.
      breakpoint: { max: 4000, min: 3000 },
      items: 4
    },
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 4
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 2
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1
    }
  }

  useEffect(() => {
    getBestSelling().then((newSelling) => setSelling(newSelling));
  }, []);

  return (
    <>
      <div className="w-full p-4 mb-12 rounded-lg bg-slate-100">
        <div className="grid grid-cols-1 mb-8 sm:grid-cols-5">
          <span className="col-start-1 text-2xl font-bold text-purple-600 sm:text-3xl">
            Filter
            <span className="text-2xl font-bold text-purple-600 sm:text-3xl">
              {" "}
              by:
            </span>
          </span>
          <span className="flex justify-center col-start-3 col-end-5 text-2xl font-bold text-purple-600 capitalize sm:text-4xl">
            {" "}
            {tags}
          </span>
        </div>

        <div className="col-span-10 rounded-lg">
          <div className="rounded-lg  bg-slate-100 ">
            <Carousel responsive={responsive} >
            {sellings.map((product, index) => (
              <button
                onClick={() =>
                  onTagsClick(
                    product.title.toLowerCase().trim() === tags
                      ? "All"
                      : product.title
                  )
                }
                className={`col-span-1 hover:shadow-lg hover:shadow-purple-600 rounded-lg transition group ${
                  product.title.toLowerCase().trim() === tags
                    ? "shadow-lg shadow-purple-600"
                    : ""
                }`}
              >
                <div className=" mx-20 md:mx-2 p-2">
                  <img
                    src={product.image.url}
                    className="flex justify-center w-40 h-40 transition duration-500 rounded-lg hover:scale-125 transorm group-hover:-translate-y-1"
                    alt={""}
                  />
                </div>
                <div className="flex justify-center pb-2 text-xl font-bold text-black transition group-hover:text-purple-600">
                  {" "}
                  {product.title}
                </div>
              </button>
            ))}
            </Carousel>
          </div>
        </div>
      </div>
    </>
  );
};

export default Best;
