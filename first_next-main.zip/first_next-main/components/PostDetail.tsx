
import moment from 'moment';
import React, {useState, useEffect, useRef} from 'react';
import { RichText } from '@graphcms/rich-text-react-renderer'
import styled from 'styled-components';
import { Helmet } from 'react-helmet';





const PostDetail = ({post}:{post:any}) => {
  const divRef = useRef<HTMLDivElement>(null);
  const [divWidth, setDivWidth] = useState(560);
  function resizeIframe(){
    if(divRef.current){
      const w = divRef.current.getBoundingClientRect().width - 30
      setDivWidth(Math.min(560, w));}
  }

  useEffect(() => {
    const handle = () => resizeIframe();
     window.addEventListener('resize', handle);
        resizeIframe()
       return () => window.removeEventListener('resize', handle);
});

  return (
    <><Helmet>

      <title>{post.title}</title>

      <meta name="description" content={post.excerpt} />

    </Helmet><div className="bg-black shadow-lg rounded-lg  pb-12 mb-8">
        <div className=" overflow-hidden shadow-md mb-6">
          <img
            src={post.featuredImage.url}
            alt={post.title}
            className="object-top h-full w-full rounded-t-lg" />

        </div>
        <div className="px-4 lg:px-0" ref={divRef}>
          <div className="block lg:flex text-center items center justify-center mb-8 w-full">
            <div className="flex items-center justify-center mb-4 lg:mb-0 w-full lg:w-auto mr-8">
              <img
                alt={post.author.name}
                height="30px"
                width="30px"
                className="align-middle rounded-full"
                src={post.author.photo.url} />
              <p className="inline align-middle text-white ml-2 font-medium text-lg">{post.author.name}</p>
            </div>
            <div className="font-medium text-white">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 inline mr-2 text-pink-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              <span className="align-middle">{moment(post.updatedAt).format('MMM DD, YYYY')}</span>
            </div>
          </div>

          <h1 className="mb-8 text-3xl font-semibold text-center sm:text-left text-white">{post.title}</h1>
          <WrapWhiteText className="text-left"><RichText content={post.content.raw.children} /></WrapWhiteText>
          <br />
          <div className="flex justify-center">
            <iframe width={divWidth} height="315" src="https://www.youtube.com/embed/o3kUvUwVSD0" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowFullScreen></iframe>
          </div>
        </div>
      </div></>
  )
}

export default PostDetail

const WrapWhiteText = styled.div`

    color: white;
    p { color: white };
    a {color:white}
`;