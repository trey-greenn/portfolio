export { default as PostCard} from './PostCard';
export { default as Categories} from './Categories';
export { default as PostWidget} from './PostWidget';
export { default as Header} from './Header';
export { default as Layout} from './Layout';
export { default as PostDetail } from './PostDetail';
export { default as Author } from './Author';
export { default as Loader} from './Loader';
export { default as Category} from './Category';
export { default as Email} from './Emails';
export { default as Toc} from './Toc';
export { default as Puzzle} from './Puzzle';
export { default as PC} from './ProdCat';
export { default as Productss} from './Nproducts';
export { default as Newhome} from './Newhome';
export { default as CarouseL} from './Carousel';
export { default as Newpc} from './Newpc';
export { default as Best} from './Tshirt';
export { default as Newplay} from './Newplay';
export { default as Puzzplay} from './Puzzplay';
export { default as Npuzzle} from './Npuzzle';
export { default as ProdDetails} from './ProdDetails';
export { default as MayLike} from './MayLike';
export { default as Footer} from './Footer';





