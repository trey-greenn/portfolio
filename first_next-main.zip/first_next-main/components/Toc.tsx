import React, { useEffect, useRef, useState } from 'react'
import Link from 'next/link';
// import { emailComment }  from '../services';

const Toc = ({posts}:{posts:any}) => {
    let result1 :any =[]
    let result: any = []
    for(let i =0; i <= posts[0].node.categoroyDescription.raw.children.length -1 ; i++){
        if(posts[0].node.categoroyDescription.raw.children[i].type === "heading-two"){
            result.push(posts[0].node.categoroyDescription.raw.children[i].children[1].id)

            // console.log(posts[0].node.categoroyDescription.raw.children[i].children[1].id)

        }
    
    }
    result.forEach((item:any)=>{
        result1.push(<li className="text-xs sm:text-sm mb-8 hover:text-blue-600" ><a className="text-white text-xs sm:text-sm mb-8 hover:text-blue-600" href={`#${item}`}>{item}</a></li>)
    })
//  Object.keys(posts[0].node.categoroyDescription.raw.children[0].type).forEach((item) =>{
//     if(posts[0].node.categoroyDescription.raw.children[0].type === "heading-two"){
//         console.log(posts[0].node.categoroyDescription.raw.children[i].children)

//     }

//  }
//  )
// console.log(posts[0].node.categoroyDescription.raw.children[0].children[1].id)
return(
    <> <div className ="bg-black shadow-lg rounded-lg p-8 pb-12 mb-8 h-screen">
    <h3 className="mb-8 text-xs sm:text-sm">Table of Contents</h3>
    <div className="grid grid-cols-1 gap-4 mb-4">
        <ul className="list-disc">
            {result1}

          

        </ul>
    </div>
      
</div></>
)


}



export default Toc

