import Link from 'next/link'
import React from 'react'
import CarouseL from './Carousel'
import Newpc from './Newpc'

const Newhome = () => {

 
  return (
    <><div className="mt-6  " style={{backgroundImage:"url(/Frame1_Rectangle.png)", backgroundSize: "2000px ", backgroundRepeat:'no-repeat'}}>
              <div className="p-8 px-2 sm:px-24 rounded-lg  sm:gap-4 "  >
                <div className="grid grid-cols-1 md:grid-cols-3 bg-black rounded-t-lg pb-4 px-6">
                      <div className="grid grid-cols-3 md:grid-cols-1 p-4 mt-2 md:mt-12 rounded-l-lg md:rounded-md transition duration-500 transorm hover:-translate-y-1">
                          <><Link href="/play">
                              <img
                                  src="/giphy (1).gif"
                                  className="rounded-l-lg sm:rounded-t-lg shadow object-cover h-32 md:h-64 md:w-full " />
                          </Link><div className=" md:col-span-1 col-start-2 col-end-4 rounded-r-lg sm:rounded-b-lg flex flex-col  px-5 bg-stone-900">
                                  <Link href="/play">
                                      <h2 className="text-lg md:text-2xl font-bold text-white py-1 sm:py-4"> Play</h2>
                                  </Link>
                                  <p className="mb-4 text-xs md:text-sm">Play a variety chess in our arcade, from, practicing chess openings or solving chess jigsaw puzzles.</p>
                            
                              </div>
                          </></div>
                          
                      <div className="grid grid-cols-3 md:grid-cols-1  p-4 mt-2 md:mt-12 rounded-md transition duration-500 transorm hover:-translate-y-1">
                          <><Link href="/shop">
                              <img
                                  src="/shopping.gif"
                                  className="rounded-t-lg shadow object-cover h-32 md:h-64 md:w-full " />
                          </Link><div className=" md:col-span-1 col-start-2 col-end-4 rounded-b-lg flex flex-col  px-5 bg-stone-900">
                                  <Link href="/shop">
                                      <h2 className="text-lg md:text-2xl font-bold text-white sm:py-4"> Shop</h2>
                                  </Link>
                                  <p className="mb-4 text-xs md:text-sm">Browse our shop for unique chess products like jigsaw puzzles, chessboards, books, and other accessories.</p>
                            
                              </div>
                          </></div>
                          
                      <div className="grid grid-cols-3 md:grid-cols-1  p-4 mt-2 md:mt-12 rounded-md transition duration-500 transorm hover:-translate-y-1">
                          <><Link href="/category">
                              <img
                                  src="/learn.gif"
                                  className="rounded-t-lg shadow object-cover h-32 w-full md:h-64 md:w-full " />
                          </Link><div className="md:col-span-1 col-start-2 col-end-4 rounded-b-lg flex flex-col  px-5 bg-stone-900">
                                  <Link href="/category">
                                      <h2 className="text-lg md:text-2xl font-bold text-white sm:py-4"> Learn</h2>
                                  </Link>
                                  <p className="mb-4 text-xs md:text-sm">Learn on how to play chess openings and dominate your opponents and expand your opening repetoire.</p>
                            
                              </div>
                          </></div>

                    </div>

        
              </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-7 bg-black mb-12 px-8 sm:px-2 -mt-8">
          <div className="col-span-1 md:col-start-2 md:col-end-5 pt-8 md:py-24 transition duration-500 transorm hover:-translate-y-1 bg-black ">
                          <><Link href="/post/emory-tate">
                              <img
                                  src="/Emory-Tate-playing-chess.jpg"
                                  className="rounded-l-lg shadow object-cover  h-full w-full" />
                          </Link>
                          </></div>
                          <div className="col-span-1 md:col-start-5  md:col-end-7 h-full md:py-24 rounded-md transition duration-500 transorm hover:-translate-y-1">
                          <><div className="rounded-r-lg flex flex-col  px-2 bg-purple-600 h-full">
                                  <Link href="/post/emorty-tate">
                                      <h2 className="text-base md:text-2xl font-bold text-white py-2"> Who was Emory Tate?</h2>
                                  </Link>
                                  <p className="mb-4 text-base md:text-2xl  md:overflow-hidden">Emory Andrew Tate Jr. (December 27, 1958 – October 17, 2015) was an American chess International Master, described by grandmaster Maurice Ashley as "absolutely a trailblazer for African-American chess".</p>
                            
                              </div>
                          </></div>
       
                                
                      
                          </div>
          
                          <CarouseL/>

                          
          
          
          
          
          </>
  )
}

export default Newhome
