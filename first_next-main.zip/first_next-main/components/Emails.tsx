import React, { useEffect, useRef, useState } from 'react'
import Link from 'next/link';
// import { emailComment }  from '../services';

const Emails = () => {
//   const [error, setError] = useState(false);
//   const [localStorage, setLocalStorage] = useState(null);
//   const emailEl: any = useRef()
//   const [showSuccessMessage, setShowSuccessMessage] = useState(false);
//   const [formData, setFormData] = useState({ email: null, storeData: false });
  
//   useEffect(()=> {
//     // setLocalStorage(window.localStorage);
//     // const initialFormData = {
//     //     email:  window.localStorage.getItem('email'), 
//     //     storeData: window.localStorage.getItem('email'),
//     //  };
//     // setFormData(initialFormData);
//     },[]);
    
//  const handleEmailSubmission = () => {
//     setError(false);
//     const {value : email} = emailEl.current;
//     if(!email){
//         setError(true);
//         return;
//     }

//     const emailObj = {
//         email
//     }

//     // if(storeData){
//     //     localStorage.setItem('email' || email)
//     // } else {
//     //     localStorage.removeItem('email' || email)
//     // }
//     emailComment(emailObj).then((res)=>{
//         setShowSuccessMessage(true);
        
//     })

//   }
  return (
    <div className ="bg-black shadow-lg rounded-lg p-8 pb-12 mb-8 h-screen">
        <h3 className="mb-8">Get the weeks best chess content</h3>
        <div className="grid grid-cols-1 gap-4 mb-4">
            <input 
            // type="text" ref={emailEl}
            className="p-4 outline-none w-full rounded-lg h-40 focus:ring-2 focus:ring-gray-200 bg-gray-100 text-gray-700" 
            name="comment" placeholder="Enter your email" 
            />
        </div>
        <button 
            type="button"
            // onClick = {handleEmailSubmission}
            className="transition duration-500 transorm hover:-translate-y-1 inline-block bg-pink-600 text-xs sm:text:lg font-medium rounded-full text-white sm:px-8 py-3 cursor-pointer">
            Sumbit
            </button>
            {/* {showSuccessMessage && <span className="text-xl float-right font-semibold mt-3 text-green-500">Comment submitted for review</span>} */}

    </div>
  )
}

export default Emails
function setError(arg0: boolean) {
    throw new Error('Function not implemented.');
}

