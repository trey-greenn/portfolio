import React from "react";

import Link from "next/link";

const Newpc = ({ post }: { post: any }) => {
  
  return (
    <>
      <div className="grid  px-4  grid-cols-9 sm:px-0 ">
        <div className="md:col-span-2 col-span-3 col-start-1 p-2 mb-4 transition duration-500 rounded-l-md transorm hover:-translate-y-1 bg-neutral-900 ">
          <img
            src={post.featuredImage.url}
            alt={post.title}
            className="my-auto object-cover md:w-full md:h-64 w-full h-fit rounded-lg shadow "
          />
        </div>
        <div className=" md:col-start-3 col-start-4 p-4 mb-4 transition duration-500  col-end-10 rounded-r-md transorm hover:-translate-y-1 bg-neutral-900">
          <h2 className="text-sm font-bold sm:px-6 md:text-2xl font-white">
            <Link className="text-white hover:text-purple-600" href={`/post/${post.slug}`}>{post.title}</Link>
          </h2>
          <p className="mt-4 text-xs md:text-2xl sm:px-6 sm:text-lg font-white">{post.excerpt}</p>
          <div className="grid grid-rows-1 grid-flow-col gap-4 "> 
          <div className="row-span-1 row-end-4 flex items-end"> <img className="text-white content-end"
          src="/tag.png"/>
          </div>
          {post.tags.map((tag: any) =><div className="row-span-1 row-end-4 text-white text-xs sm:text-sm"> {tag.title}</div> )}
          </div>
      
        </div>
      </div>
    </>
  );
};

export default Newpc;
