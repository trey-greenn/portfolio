import React, { useEffect, useState } from 'react'
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import { getCategories } from '../services';
import Link from 'next/link';

const CarouseL = () => {
    const responsive = {
        superLargeDesktop: {
          // the naming can be any, depends on you.
          breakpoint: { max: 4000, min: 3000 },
          items: 5
        },
        desktop: {
          breakpoint: { max: 3000, min: 1024 },
          items: 3
        },
        tablet: {
          breakpoint: { max: 1024, min: 464 },
          items: 2
        },
        mobile: {
          breakpoint: { max: 464, min: 0 },
          items: 1
        }
      }
      const [categories, setCategories] = useState([] as any[]);

      useEffect(() => {
        getCategories()
          .then((newCategories) => setCategories(newCategories))
    
      },[]);
  return (
    <>
    <div className="px-16 sm:px-40 mt-4 ">
      <span className="text-slate-300  font-bold text-3xl sm:text-3xl hover:text-purple-600 ">Chess</span>
      <span className="text-purple-600  font-bold text-3xl sm:text-4xl hover:text-purple-600"> Openings</span>
      </div>
        <Carousel responsive={responsive} className="mb-20 mt-10 sm:px-20 bg-violet-950">
                          {categories.map((category, index) => (
                          <div className=" bg-black p-4 transition duration-500 transorm bg-violet-950 hover:-translate-y-1">  
                            <Link key={index} href={`/category/${category.slug}`}>
                              <div className="font-bold flex justify-center pb-4 hover:text-purple-600"> {category.title}</div>
                            </Link>
                            <div className="flex justify-center">
                              <Link href={`/category/${category.slug}`}>
                                <img src={category.categoryImage.url} className="h-48 md:h-64 w-full rounded-lg" alt={''} />
                              </Link>
                            </div>
                          </div>
                          )
                        )}
        </Carousel>
        </>
 
  )
}

export default CarouseL
