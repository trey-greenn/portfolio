import React from 'react'

const Author = ({ author }: {author:any}) => {
  return (
    <div>
      <h3>{author.name}</h3>
    </div>
  )
}

export default Author
