import React, { useEffect, useState } from 'react'
import { getBestSelling } from '../services';
import Link from 'next/link';

const MayLike = () => {
    const [sellings, setSelling] = useState([] as any[]);
  
    useEffect(() => {
        getBestSelling()
        .then((newSelling: React.SetStateAction<any[]>) => setSelling(newSelling))
  
    },[]);

    
  return (
    <>
        <div className= "maylike-products-wraper flex justify-center mt-12 pb-12">
            <div className="marquee">
                <div className="maylike-products-container track mb-12">
                  {sellings.map((product, index) => (
                                      
                          <><a className="text-white text-center mt-2">
                            <Link href={`${product.url}`}>
                            <img src={product.image.url}
                      className="h-64 w-64 mx-12 rounded-lg hover:scale-110 transition duration-500 transorm hover:-translate-y-1" alt={''} /></Link>
                      {product.prodTitle}
                      <div>
                      <span>{product.price}</span>
                      </div>
 
                      <div>
     
                      <button className="snipcart-add-item bg-purple-600 rounded-lg p-2 mt-4"
                        data-item-id={product.prodTitle}
                        data-item-name={product.prodTitle}
                        data-item-price={product.price}
                        data-item-url={`${product.url}`}
                        data-item-description="Nice Quality"
                        data-item-image={product.image.url}
                        data-item-custom1-name="Variant"
                        data-item-custom1-options={product.options}>
                        Add to Cart
                      </button>
                      </div>
                      
                  
                      </a>

                      
                      </>

                  )
              )}

                </div>

            </div>

            </div></>
  )
}

export default MayLike
