import Image from 'next/image'
import Link from 'next/link'

const navigation = {
  navlinks: [
    { name: "Learn", href: 'category' },
    { name: "Chess Openings", href: 'category' },
    { name: "Blog", href: 'post' },
    { name: "Tactics", href: 'tactics' },

  ],
  services: [
    { name: 'Shop', href: 'shop' },
    { name: 'Clothes', href: 'shop/clothes' },
    { name: 'Jigsaw Puzzles', href: 'shop/jigsaw-puzzle' },
    { name: 'Posters', href: 'shop/poster' },
  ],
  Home: [
    { name: 'Play', href: 'play' },
    { name: 'Online Jigsaw Puzzle', href: 'play/jigsaw-puzzle' },
    { name: 'Chess Puzzle', href: 'chess-board' },
    { name: 'Opening Engine', href: 'chess-board' },
    { name: 'Meme Chess', href: 'chess-board' },

  ],
  contactus: [
    { name: 'Shop', href: '/shop' },
  ],





}

export default function Footer() {
    return (
    <><footer className="bg-black border-t" aria-labelledby="footer-heading">
            <h2 id="footer-heading" className="sr-only">
                Footer
            </h2>
      
        
        <div className=" mt-4 grid grid-cols-1 md:grid-cols-3 px-8 md:px-24">
            <div className="flex justify-center grid grid-rows-4 mb-8 md:mb-0 ">
                {navigation.navlinks.map((item) => (
                    <>
                        <Link href={`/${item.href}`} className="text-white">
                            {item.name}
                        </Link>
                    </>
                ))}
            </div>
            <div className="flex justify-center grid grid-rows-4 mb-8 md:mb-0">
                {navigation.services.map((item) => (
                    <>
                        <Link href={`/${item.href}`} className="text-white">
                            {item.name}
                        </Link>
                    </>
                ))}
            </div>
            <div className="flex justify-center grid grid-flow-row  mb-8 md:mb-0">
                {navigation.Home.map((item) => (
                    <>
                        <Link href={`/${item.href}`} className="text-white">
                            {item.name}
                        </Link>
                    </>
                ))}
            </div>

                
           
            </div>
            <div className="mt-12 border-t border-gray-200 pt-8 mb-8">
                <div className="grid grid-cols-3 flex justify-center">
                    <Link className="col-start-1 text-center" href="https://instagram.com/theopenchess"><span className="text-white ">Instagram</span></Link>


                    <Link className="col-start-2 text-center" href="https://instagram.com/theopenchess"><span className="text-white ">Youtube</span></Link>


                    <Link className="col-start-3 text-center" href="https://instagram.com/theopenchess"><span className="text-white ">Tik Tok</span></Link>

                    </div>
                    <p className="text-base text-gray-400 py-6 text-center">&copy; 2023 THE OPEN CHESS,  Inc. All rights reserved.</p>
                </div>
            </footer></>
            )}