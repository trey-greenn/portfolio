import Link from 'next/link'
import React from 'react'

const Newplay = () => {
  
  return (
    <div className="grid grid-cols-1 sm:grid-cols-5">
    <div className="col-start-2 col-end-5">
    <Link href="/play/jigsaw-puzzle/emory-tate">
                  <img
                      src="/giphy (1).gif"
                      className="rounded-lg shadow object-cover h-96 w-full" />
              </Link>

    </div>

</div>
  )
}

export default Newplay
