import React, {useState, useEffect} from 'react';
import Link from 'next/link';

import { getCategories } from '../services';

const Categories = () => {
  const [categories, setCategories] = useState([] as any[]);

  useEffect(() => {
    getCategories()
      .then((newCategories) => setCategories(newCategories))

  },[]);

  return (
          <><div>
      <h2 className="text-xl font-bold border-b pb-4 flex justify-center text-white bg-black w-screen"> Openings</h2>

    </div><div className="col-span-10 flex-justify center w-full bg-violet-950 py-4">
        <div id="category" className="grid grid-cols-1 md:grid-cols-4 sm:grid-cols-2 gap-2 px-8 bg-violet-950">
          {categories.map((category, index) => (
            <div className="col-span-1 bg-black p-4 transition duration-500 transorm hover:-translate-y-1">
              <Link key={index} href={`/category/${category.slug}`}>
                <div className="font-bold flex justify-center pb-4 hover:text-purple-600"> {category.title}</div>
              </Link>
              <div className="flex justify-center">
                <Link href={`/category/${category.slug}`}>
                  <img src={category.categoryImage.url} className="h-64 w-full rounded-lg" alt={''} />
                </Link>
              </div>
            </div>
          )
          )}


        </div>

      </div></>
  )
}

export default Categories
