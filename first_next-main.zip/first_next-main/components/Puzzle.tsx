import React, {useState, useEffect} from 'react';
import Link from 'next/link';

import { getPuzzle } from '../services';

const Puzzles = () => {
    const [puzzle, setPuzzles] = useState([] as any[]);
  
    useEffect(() => {
      getPuzzle()
        .then((newPuzzle) => setPuzzles(newPuzzle))
  
    },[]);


  return (
    <>
          <div>
        <div className=" mb-8 ">
            <span className="text-white font-bold text-3xl sm:text-7xl hover:text-purple-600">Shop by</span>
            <span className="text-purple-600 font-bold text-3xl sm:text-7xl hover:text-purple-600"> Category</span>
          </div> 
                <div className="col-span-10">
                    <div className="grid grid-cols-1 sm:grid-cols-5 gap-4">
                        {puzzle.map((product, index) => (
                        <div className="col-span-1 bg-black p-4">  
                    
                            <div className="font-bold flex justify-center pb-4 hover:text-purple-600"> {product.productTitle}</div>
                    
                        <div className="flex justify-center">
                            <a href={`${product.productLink}`} >
                                <img src={product.productImage.url} width="200" height="250" alt={''} />
                            </a>

                        </div>
                        <div className="col-span-1 mt-4 flex justify center">
                            <a className=" flex justify-center text-lg font-semibold text-center"><span className="transition duration-500 transorm hover:-translate-y-1 inline-block bg-purple-600 text-lg font-medium rounded-full text-white px-8 py-3 cursor-pointer"><a className="text-white font-semibold" href={product.productLink}>${product.productPrice}</a></span></a>
                            </div>
                        </div>
                        )
                    )}
                    </div>
                </div> 
                             
            </div>
            </>
            
  )
}

export default Puzzles
