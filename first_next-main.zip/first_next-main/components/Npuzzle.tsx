import Script from 'next/script';
import React, { useState } from 'react'
import { Helmet } from 'react-helmet';
import { JigsawPuzzle } from 'react-jigsaw-puzzle/lib'
import 'react-jigsaw-puzzle/lib/jigsaw-puzzle.css';
import styled from 'styled-components';

const Npuzzle = ({jigsaw}:{jigsaw:any}) => {
    const [text, setText] = useState("Unpuzzle the pieces!!");
      
    const set = () => {
        setText("Congratulations!!");
    };
  return (
    <>
    <Helmet>
    <Script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2274033795015131"
          crossOrigin="anonymous"/>

        <title>{jigsaw[0].titleText}</title>

        <meta name="description" content={jigsaw[0].metaDescription}/>

</Helmet>
    
    <h2 className="tag">{text}</h2>
         <PuzzleClass>
         <JigsawPuzzle
         imageSrc={jigsaw[0].image.url}
         rows={3}
         columns={3}
         onSolved={set}
    
     />
    </PuzzleClass>


    
</>
  )
}

export default Npuzzle

const PuzzleClass = styled.div`

    width: 75%;
    height: 75%%;
    border: 2px solid black;
    margin: auto;
    box-shadow: 0 5px 10px 2px rgba(0, 0, 0, 0.25);
`;