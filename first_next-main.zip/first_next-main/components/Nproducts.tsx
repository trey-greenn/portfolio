import { Product, ProductEdge } from "../types";
import React, { useEffect, useState } from "react";
import { getProds, getProdsByTags, getProducts } from "../services";

import Head from "next/head";
import Link from "next/link";

interface Props {
  tags: string;
}

const Productss: React.FC<Props> = ({ tags }) => {
  const [products, setProducts] = useState<ProductEdge[] | []>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    if (tags === "all")
      getProds()
        .then((newProducts) => setProducts(newProducts))
        .finally(() => setLoading(false));
    else
      getProdsByTags(tags)
        .then((newProducts) => setProducts(newProducts))
        .finally(() => setLoading(false));
  }, [tags]);
  return (
    <>

      <div className="col-span-10">
      <div className="grid shadow-2xl grid-cols-1 md:grid-cols-4 sm:grid-cols-2 shadow-purple-600 ">

          {!loading &&
            products?.map((product, index) => (
        
              <div className="grid grid-cols-6 hover:shadow-lg hover:shadow-purple-600 py-4 lg:py-0">
              <>
              <div className="col-start-1 col-end-5 md:col-start-1 md:col-span-6 m-1 md:m-4 transition duration-500 rounded-md transorm hover:-translate-y-1 ">
               
                  <Link
                    
                    href={`/product/${product.node.slug}`}
                    className="flex justify-center"
                  >
                    <img
                      src={product.node.productImage.url}
                      className="object-cover w-60 h-60 transition duration-300 ease-in-out rounded-t-lg hover:scale-125"
                    />
                  </Link>
                  </div>
                  <div className="col-start-5 col-end-7 md:col-start-1 md:col-span-6 flex flex-col items-center justify-center p-2 md:p-5 rounded-b-lg">
                    <p className="mb-2 text-xs md:text-sm font-semibold text-center">
                      {product.node.productComp}: {product.node.productTitle}
                    </p>
                    <p className="text-lg">${product.node.productPrice}</p>
                    {/* <Link href={product.node.productLink}> */}
                    <span className="inline-block w-full  py-3  mt-8 mb-6 text-xs md:text-lg font-medium text-center text-white transition duration-500 bg-purple-600 rounded-lg cursor-pointer transorm hover:-translate-y-1">
                      <button
                        className="snipcart-add-item"
                        data-item-id={product.node.slug}
                        data-item-name={product.node.productTitle}
                        data-item-price={product.node.productPrice}
                        data-item-url={`/product/${product.node.slug}`}
                        data-item-description="Nice Quality"
                        data-item-image={product.node.productImage.url}
                        data-item-custom1-name="Variant"
                        data-item-custom1-options={product.node.prodOptions}
                      >
                        Add to Cart
                      </button>
                    </span>
                  </div>
                </>
                </div>

      
   
              
            ))}
            </div>
            </div>

            
          {!loading && !products.length && (
            <p className="px-10 py-20 text-2xl font-bold text-center text-purple-600 sm:text-3xl sm:col-span-4">
              No items found
            </p>
          )}
          {loading && (
            <p className="px-10 py-20 text-2xl font-bold text-center text-purple-600 sm:text-3xl sm:col-span-4 animate-pulse">
              Loading...
            </p>
            
          )}
        
      
    </>
  );
};
export default Productss;
