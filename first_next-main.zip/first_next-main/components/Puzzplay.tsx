import React, { useEffect, useState } from 'react'
import { getJigsaw } from '../services';

const Puzzplay = ({jigsaws}:{jigsaws:any}) => {
    const [jigsaw, setJigsaws] = useState([] as any[]);

    useEffect(() => {
        getJigsaw()
        .then((newJigsaws: any) => setJigsaws(newJigsaws))

    },[]);
  return (
    <>

     
                
        <div className=" flex justify-center py-2 ">
            <a className="" href={`/play/jigsaw-puzzle/${jigsaws.slug}`} >
              <div className="w-full flex justify-center py-2"><span className="text-white flex justify-center bg-red-600 font-bold w-fit text-center px-2 text-sm rounded-full">{jigsaws.titleText}</span></div>
                <img src={jigsaws.image.url}  className="h-36 w-52 px-1 rounded-xl hover:brightness-125 transition duration-500 transorm hover:-translate-y-1" alt={''} />
                
            </a>
    </div> 
                       

      </>
  )
}

export default Puzzplay
