module.exports = {
    siteUrl: 'https://theopenchess.com',
    generateRobotsTxt: true, // (optional)
    // ...other options
    outDir:".out/"
  }