import { gql} from "graphql-request";

import { GraphQLClient } from "graphql-request";

const graphqlURL =
  "https://api-us-east-1-shared-usea1-02.hygraph.com/v2/clkcs05i74r5w01t44pye0hbi/master";
// const graphqlURL2 = 
// "https://api-us-east-1-shared-usea1-02.hygraph.com/v2/cljm6txde1v2301ul9e6u48c0/master";

// const graphqlURL3 =
// "https://api-us-east-1-shared-usea1-02.hygraph.com/v2/cljm851zy1vc801tc3tvu0bee/master";

export const getPosts = async () => {
  const graphQLClient = new GraphQLClient(
    graphqlURL
  );
  const query = gql`
  {
    postsConnection(first: 20) {
      edges {
        node {
          author {
            name
            id
            photo {
              url
            }
            posts {
              categories {
                name
                slug
                tags
              }
            }
          }
          createdAt
          slug
          title
          excerpt
          featuredImage {
            url
          }
          updatedAt
        }
      }
    }
  }
  
  `;
  const result = await graphQLClient.request<any>(query);

  return result.postsConnection.edges;
};

export const getPostsOnly = async () => {
  const graphQLClient = new GraphQLClient(graphqlURL);
  const query = gql`
  query GetPosts {
    posts (first:20){
      id
      title
      tags {
        title
      }
      excerpt
      featuredImage {
        url
      }
      slug
    }
  }
  `;
  const result = await graphQLClient.request<any>(query);

  return result.posts;
};

export const getPostsByTag = async (tag: string) => {
  const graphQLClient = new GraphQLClient(graphqlURL);
  const query = gql`
    query GetPostsByTag($tag: String!) {
      posts(where: { tags_some: { title: $tag } }) {
        id
        title
        tags {
          title
        }
        excerpt
        featuredImage {
          url
        }
      }
    }
  `;
  const result = await graphQLClient.request<any>(query, { tag });

  return result.posts;
};

export const getTags = async () => {
  const graphQLClient = new GraphQLClient(graphqlURL);
  const query = gql`
    query GetTags {
      tags {
        title
      }
    }
  `;
  const result = await graphQLClient.request<any>(query);

  return result.tags.map((tag: any) => tag.title);
};

export const getRecentPosts = async () => {
  const gCP = new GraphQLClient(graphqlURL);
  const query = gql`
    query Assets {
      posts(orderBy: createdAt_ASC, last: 3) {
        title
        featuredImage {
          url
        }
        createdAt
        slug
      }
    }
  `;
  const result = await gCP.request<any>(query);
  return result.posts;
};

export const getSimilarPosts = async (categories: any, slug: any) => {
  const gSP = new GraphQLClient(graphqlURL);
  const query = gql`
    query GetPostDetails($slug: String!, $categories: [String!]) {
      posts(
        where: {
          slug_not: $slug
          AND: { categories_some: { slug_in: $categories } }
        }
        last: 3
      ) {
        title
        featuredImage {
          url
        }
        
        createdAt
        slug
      }
    }
  `;
  const result = await gSP.request<any>(query, { slug, categories });
  return result.posts;
};

export const getCategories = async () => {
  const gC = new GraphQLClient(graphqlURL);
  const query = gql`
    query Assets {
      categories(first: 41) {
        name
        slug
        title
        categoryImage {
          url
        }
      }
    }
  `;
  const result = await gC.request<any>(query);

  return result.categories;
};

export const getPostDetails = async (slug: any) => {
  const gDP = new GraphQLClient(graphqlURL);
  const query = gql`
    query GDP($slug: String!) {
      post(where: { slug: $slug }) {
        createdAt
        content {
          raw
        }
        featuredImage {
          url
        }
        slug
        title
        excerpt
        author {
          name
          photo {
            url
          }
        }
        categories {
          name
          slug
        }
        metaDescription
      }
    }
  `;
  const result = await gDP.request<any>(query, { slug });
  return result.post;
};

export const getCategoryPost = async (slug: any) => {
  const gCP = new GraphQLClient(graphqlURL);
  const query = gql`
  query GCP($slug: String!) {
    categoriesConnection(first: 41, where: {slug: $slug}) {
      edges {
        node {
          slug
          categoroyDescription {
            raw
          }
          categoryImage {
            url
          }
          title
          youtubeVid
          name
          metaDescription
          posts {
            title
            slug
          }
          author {
            name
            photo {
              url
            }
          }
          updatedAt
        }
      }
    }
  }
  `;
  const result = await gCP.request<any>(query, { slug });
  return result.categoriesConnection.edges;
};

export const getProducts = async (slug: any) => {
  const gP = new GraphQLClient(graphqlURL);
  const query = gql`
  query MyQuery($slug: String!) {
    product(where: {slug: $slug}) {
      productComp
      productTitle
      productImage {
        url
      }
      productPrice
      slug
      productImages {
        url
      }
      prodOptions
      prodDescription {
        raw
      }
    }
  }
  
  `;
  const result = await gP.request<any>(query, { slug });

  return result.product;
};

export const getPuzzle = async () => {
  const gPp = new GraphQLClient(graphqlURL);
  const query = gql`
    query MyQuery {
      puzzle(first: 2) {
        productComp
        productTitle
        productImage {
          url
        }
        productPrice
        productLink
      }
    }
  `;
  const result = await gPp.request<any>(query);

  return result.puzzle;
};

export const getProdCat = async () => {
  const gPp = new GraphQLClient(graphqlURL);
  const query = gql`
    query MyQuery {
      productCats {
        image {
          id
          imageProductCat {
            image {
              url
            }
  
          }
        }
        title
      }
    }
  `;
  const result = await gPp.request<any>(query);

  return result.productCats;
};

export const getBestSelling = async () => {
  const gBs = new GraphQLClient(graphqlURL);
  const query = gql`
  query MyQuery {
    bestSellings {
      title
      image {
        url
      }
      prodTitle
      price
      options
      url
    }
  }
  
  `;
  const result = await gBs.request<any>(query);

  return result.bestSellings;
};

export const getJigsawDetails = async (slug: any) => {
  const gJd = new GraphQLClient(graphqlURL);
  const query = gql`
    query MyQuery($slug: String!) {
      jigsaws(where: {slug: $slug}) {
        image {
          url
        }
        slug
        titleText
        metaDescription
      }
    }
  `;
  const result = await gJd.request<any>(query, { slug });
  return result.jigsaws;
};

export const getJigsaw = async () => {
  const gJ = new GraphQLClient(graphqlURL);
  const query = gql`
    query MyQuery {
      jigsawsConnection {
        edges {
          node {
            image {
              url
            }
            slug
            titleText
          }
        }
      }
    }
  `;
  const result = await gJ.request<any>(query);
  return result.jigsawsConnection.edges;
};

export const getProds = async () => {
  const gPs = new GraphQLClient(graphqlURL);
  const query = gql`
  query MyQuery {
    productConnection(first: 12) {
      edges {
        node {
          productComp
          productTitle
          productImage {
            url
          }
          productPrice
          slug
          tags
          prodOptions
        }
      }
    }
  }
  `;
  const result = await gPs.request<any>(query);
  return result.productConnection.edges;
};

export const getProdsByTags = async (tags: string) => {
  const gPs = new GraphQLClient(graphqlURL);
  const query = gql`
    query MyQuery($tags: String!) {
      productConnection(first: 15, where: { tags: $tags }) {
        edges {
          node {
            productComp
            productTitle
            productImage {
              url
            }
            productPrice

            slug
            tags
            prodOptions
          }
        }
      }
    }
  `;
  const result = await gPs.request<any>(query, { tags });
  return result.productConnection.edges;
};
