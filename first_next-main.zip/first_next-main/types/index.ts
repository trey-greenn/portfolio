export type Product = {
  prodOptions: any;
  productComp: string;
  productTitle: string;
  productImage: {
    url: string;
  };
  productPrice: number;
  productLink: string;
  slug: string;
  tags: string[];
};

export type ProductEdge = {
  node: Product;
};
