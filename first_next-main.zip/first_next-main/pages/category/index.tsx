import { Helmet } from "react-helmet";
import styled from "styled-components";
import Category from "../../components/Category";
import Script from "next/script";
import { ChevronDownIcon } from "@heroicons/react/24/outline";
import Link from "next/link";

export default function CategoryPage(){

    return(
        <div>
            <Helmet>
                <title>Chess openings</title>
                <meta name="description" content="Uncover the strategic importance of the chess opening phase. Learn how to lay a solid foundation and set the tone for a successful game."/>
            </Helmet>
            
        
            <div className="">
            <div className="bg-black w-screen">
              <div className="grid grid-cols-1 sm:grid-cols-5 gap-4 bg-black  rounded-lg py-4 mb-8">
                <div className="col-start-1 col-span-5 px-8 md:px-20">
                  <div className='grid grid-cols-5'>
               
                    <Link className="col-start-1 col-end-5 md:col-end-3 rounded-lg px-1 hover:bg-purple-600" href="#category">
                  <h1 className="text-3xl md:text-4xl text-left font-bold mb-2 text-white ">Chess Openings
                  </h1>
                  </Link>
                  <Link className="col-start-5 md:col-start-3 rounded-lg p-4 hover:bg-purple-600 w-fit" href="#category">

                  <ChevronDownIcon className=" h-5 w-5 flex-none text-white " aria-hidden="true"/></Link></div>
                  <p className="text-white mb-2 text-xs md:text-base">There are three phases of a chess game: the chess opening, middlegame, and endgame. Chess players want the best chess opening in order to establish dominance and momentum that carries into the other phases of the game. 
                  The objective is to win, so a strong start should lead to a strong ending. If you have not caught on by now, a chess opening is the initial stage of a chess game. Typically in the range of the first 1 - 16 moves by both black and white. 
                  According to “The Oxford Companion to Chess”, there are over 1,300 titled openings and opening’s variants.</p> 
                  <h2 className="text-2xl font-semibold mb-2">What is a Chess Opening?</h2>
                  <p className="text-white mb-2 text-xs md:text-base">The opening phase of a chess game is a realm of indeterminacy and speculation, where strategy takes center stage. It is during this phase that players outline their general plan of campaign and establish a foundation for their operations, 
                    relatively independent of the opponent's moves. In the opening, the relations between opposing forces are vague, attack and defense are minimal, and there is no pressing obligation or necessity dictating specific actions. It is a period of exploration, 
                    where players rely on their understanding of chess as a whole to devise their initial moves and evolve a general position. However, the opening is also an area of difficulty and potential disappointment, as experimentation and exploration may not always yield the desired results</p>
                    <h2 className="text-2xl font-semibold mb-2">The Evolution of Position</h2>
                  <p className="text-white mb-2 text-xs md:text-base">Before the opening phase, a tangible and salient position does not exist. Even among skilled players, there can be disagreements about the first few moves of a game. Each player may have their own ideas, and multiple approaches can be equally valid. 
                  The opening serves the purpose of evolving a general position from which advantageous positions can be derived and unfavorable positions can be excluded. The player's judgment plays a crucial role in this process, as it is their understanding of chess that guides their decision-making. 
                  To make adequate arrangements and dispositions, the player must have a notion of their objectives and be able to recognize them on the board. Thus, a fair knowledge of the logical antecedents—the middle game and endgame—is necessary to truly comprehend the opening.</p>
                    <h2 className="text-2xl font-semibold mb-2">The Impact of the Opening on the Game's Outcome</h2>
                  <p className="text-white mb-2 text-xs md:text-base">Interestingly, the opening often plays a relatively small role in the final outcome between highly skilled players. Once the forces meet and a collision occurs at an important point on the board, the opening plans give way to tactical considerations, 
                  and the real battle begins. Skilled players adapt their strategies, compromise</p>
                </div>
              </div>
              </div>
          
                   
                        <Category  />
                
             
               
            </div>
        </div> 
       
    )
}
const Wrap = styled.div`
    max-width: 700px;

    @media only screen and (max-width: 800px){
        max-width: 100%;
    }
`;