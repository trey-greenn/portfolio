import React, {useRef, useState, useEffect} from 'react';
import { useRouter } from 'next/router';
import { GetStaticProps} from 'next';
import { getCategories, getCategoryPost } from '../../services';
import {  Loader } from '../../components';
import { RichText } from '@graphcms/rich-text-react-renderer'
import styled from 'styled-components';
import { Helmet } from "react-helmet";
import Image from 'next/image';
import moment from 'moment';






const CategoryPost = ({ posts }:{posts:any}) => {
  const divRef = useRef<HTMLDivElement>(null);
  const [divWidth, setDivWidth] = useState(560);
  function resizeIframe(){
    if(divRef.current){
      const w = divRef.current.getBoundingClientRect().width - 30
      setDivWidth(Math.min(560, w));}
  }

  useEffect(() => {
    const handle = () => resizeIframe();
     window.addEventListener('resize', handle);
        resizeIframe()
       return () => window.removeEventListener('resize', handle);
})

    
  const router = useRouter();
    if (router.isFallback) {
      return <Loader />;
    }


    return (
      
      <div className="">
            <Helmet>
              {posts.map((post: {node:any;}, index: React.Key | null | undefined) => (
                <title>{post.node.name}</title>
              ))}
              {posts.map((post: {node:any;}, index: React.Key | null | undefined) => (
                <meta name="description" content={post.node.metaDescription}/>
              ))}
            </Helmet>
            
            <div className="">
              <div className="grid grid-cols-1 sm:grid-cols-6 sm:px-2">
                <div className="col-span-1">

              
                </div>
                <div className="sm:col-start-2 sm:col-end-6 mb-12 bg-black px-4 sm:px-0 ">
                  {posts.map((post: { node: any; }, index: React.Key | null | undefined) => (
                      <><div className="text-center mb-8 "key = {index}>
                      <h1 className="text-lg sm:text-3xl font-semibold text-white"> {post.node.name}</h1></div> 
                      <div className =" overflow-hidden shadow-md mb-10 text-center" >
                        < img 
                            loading="lazy"
                            src={post.node.categoryImage.url}
                            alt={post.node.name}
                      
                            className=" h-full w-full rounded-t-lg"
                        />
                    </div>
                    <div className="px-4 lg:px-0" ref={divRef}>
                    <div className="grid grid-cols-7 lg:flex sm:text-center items center justify-center  w-full">
                        <div className="col-start-2 col-span-3 flex items-center justify-center mb-4 lg:mb-0 w-full lg:w-auto mr-8">
                          <img
                            loading="lazy"
                            alt={post.node.author.name}
                            className="align-middle rounded-full"
                            src={post.node.author.photo.url}
                            height="30px"
                            width="30px"
                          />
                          <p className="inline align-middle text-white ml-2 font-medium text-sm md:text-lg">{post.node.author.name}</p>
                        </div>
                        <div className="font-medium text-white col-start-5 col-span-3 ml-2 sm:ml-0">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 inline mr-2 text-pink-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                          </svg>
                          <span className="text-sm md:text-lg align-middle">{moment(post.node.updatedAt).format('MMM DD, YYYY')}</span>
                        </div>
                      </div>
                      </div>
                      <WrapWhiteText className="mb-8 text-left "> <RichText content = {post.node.categoroyDescription.raw}/> </WrapWhiteText>
                      <div className="flex justify-center mb-8">
                        <iframe loading="lazy" width={divWidth} height="315" src={post.node.youtubeVid} title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowFullScreen></iframe>
                      </div>
                      </>
                      ))}
                      </div>
                </div>
                <div> 
                </div>       
              </div>
            </div>
    );
  };

    
export default CategoryPost

export const getStaticProps:GetStaticProps = async({params}) =>{
    const posts = (await getCategoryPost(params!.slug))
    return {
        props: {posts}
    }
  }
  
export async function getStaticPaths() {
    const categories = await getCategories();
    return {
    paths: categories.map(( {slug}:{slug:any}  ) => ({ params: { slug } })),
    fallback: true,
    };
}

const WrapWhiteText = styled.div`
    justify-content: center;
    p { color: white };
    a{color:white}
`;

