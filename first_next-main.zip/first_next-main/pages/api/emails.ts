// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import type { NextApiRequest, NextApiResponse } from 'next'

import { GraphQLClient, gql } from 'graphql-request';

const graphqlAPI = ("https://api-us-east-1-shared-usea1-02.hygraph.com/v2/clczipqce4ao501ta9arl64fp/master");

type Data = {
  name: string
}

// export default async function emails({ body }:any, res:any
//   ) {
//   const {email} = JSON.parse(body);
//   const graphqlClient = new GraphQLClient(graphqlAPI, {
//     headers:{
//       authorization: `Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImdjbXMtbWFpbi1wcm9kdWN0aW9uIn0.eyJ2ZXJzaW9uIjozLCJpYXQiOjE2Nzk3NzY0MTMsImF1ZCI6WyJodHRwczovL2FwaS11cy1lYXN0LTEtc2hhcmVkLXVzZWExLTAyLmh5Z3JhcGguY29tL3YyL2NsY3ppcHFjZTRhbzUwMXRhOWFybDY0ZnAvbWFzdGVyIiwibWFuYWdlbWVudC1uZXh0LmdyYXBoY21zLmNvbSJdLCJpc3MiOiJodHRwczovL21hbmFnZW1lbnQuZ3JhcGhjbXMuY29tLyIsInN1YiI6IjI0MTY5OWJiLTZjNDAtNDhkOC04MjM2LWYyNjMyY2UwOGM0MCIsImp0aSI6ImNsZm9maTdpbzA4b3owMXQ4Z3pzZGQ0aDIifQ.uTMMRWeCvtTu7wwPlmakOrIZE_FBlp6J69j6bwI9oB9hZmh7alF074FgzPM0o4jpQSJGXftElbrQ83zCmURU02e2eVWaTK51IHFPDrYy--C50oDYo8BCXVhxqyTGAL08bIZ-lpJr7dZiivExO7ECklyNI9ID-82UtrUzfRH62gPoDYQgYumWVq06ye_KMeLLm_LqbFvrYzvSdfIpe8g_pg0DJc26wVN6-4M-_eH6PYceCtl8HwDifYpnytW56WMOI-p7SYH5VPleGP4leg0QQ_bd42k5jnhibgEaIPU0SiT1GdaAKAjVYA39tJtCGbXn6IzMeSwniOBFPc2rS_XWZ3ElfK_DQ_y6O8tx0qfyOrX0YxOMOYMB1A2l-vgqWIM2Nif4QVWQPrhTza_zsRR-Y871Wi6SIag7-vZvhDrQEMTPSTlpt4oYarmrF17f--owIXUNZmk0VyvE0H2YP19tiwsvqIxWRoyp8gBpWk5eRUoiiZlNs-lUFXjoR4mioyHdhPgNOiBr1X5tRLh-KjAuGN2Vus6qU0Y0wGCzsmF5UM_KgC_e_7Gxuld9FdQ0hWjxH9gp4ciXaT5B1FFtxcS7hBJpo3qU90C3mmnE3ZUWZaew991UDT--Hn088OS-md1u66a5q6MIdxJk0U0J5OlQ9HW8ZUhn8GqvzO8DpMdW4j0`
//     },
//   });

//   const query = gql`
//     mutation Email($email: String!){
//       createEmailSubmit(data: {email: $email}){
//         email
//       }
//     }
//   `
//   const {result} = await graphqlClient.request(query, 
//     {email}
//   )
//   res.status(201).json(result);

// }
