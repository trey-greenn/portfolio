import React from 'react'

import { getPostDetails, getPosts } from '../../services';
import { GetStaticProps} from 'next';
import dynamic from 'next/dynamic';
const PostDetail = dynamic(() => import("../../components/PostDetail"))
const Category = dynamic(() => import("../../components/Category"))

const PostDetails = ({ post }:{post:any}) => {
  if(!post){
    return <div/>
  }
  
    return (
      <>
        
            <div className="">
              <div className="grid grid-cols-1 sm:grid-cols-6 ">

                <div className="sm:col-start-2 sm:col-end-6 mb-12 bg-black  ">
              <PostDetail post={post}/>
            </div>
          </div>

          <div className="mt-8">
            <Category />
          </div>
        </div>
      </>
    );
  };

export default PostDetails;

export const getStaticProps:GetStaticProps = async({params}) =>{
  const data = (await getPostDetails(params!.slug))
  return {
      props: {post:data}
  }
}

export async function getStaticPaths() {
    const posts = await getPosts();
    return {
      paths: posts.map(( {node:  {slug =""} } ) => ({ params: { slug } })),
      fallback: true,
    };
  }
