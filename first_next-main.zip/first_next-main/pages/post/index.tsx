import { Categories, Newpc, PostCard, PostWidget } from "../../components";
import { Key, useEffect, useState } from "react";
import {  getPostsByTag, getPostsOnly, getTags } from "../../services";

import { GetStaticProps } from "next";
import Script from "next/script";

export default function Posts({ fetchedPosts, fetchedTags }: any) {
  const [posts, setPosts] = useState<any>(fetchedPosts ?? []);
  const [selectedTag, setSelectedTag] = useState("all");
  const [tags, setTags] = useState(["all", ...fetchedTags] ?? []);

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    if (selectedTag !== "all")
      getPostsByTag(selectedTag)
        .then((newPosts) => setPosts(newPosts))
        .finally(() => setLoading(false));
    else {
      setPosts(fetchedPosts);
      setLoading(false);
    }
  }, [selectedTag]);

  return (
    <>
      <Script
        strategy="lazyOnload"
        src={"https://www.googletagmanager.com/gtag/js?id=G-755JVKX9DY"}
      />
      <Script>
        {`
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());
            
              gtag('config', 'G-755JVKX9DY');
              `}
      </Script>

          <div className="col-span-1 lg:col-span-8">
            <div className="flex flex-wrap items-center justify-center gap-2 mb-6">
              {tags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => setSelectedTag(tag)}
                  className={`px-3 py-1 capitalize rounded-full shadow shadow-purple-500/50 border border-purple-500 transition ${
                    selectedTag === tag ? "bg-purple-500 font-semibold" : ""
                  }`}
                >
                  {tag}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-12 px-0 md:px-4">
              <div className="col-start-1 col-end-13 md:col-end-10">
            {!loading &&
              posts?.map((post: any) => <Newpc key={post.title} post={post} />)}
            {loading && (
              <p className="py-20 text-xl font-bold text-center text-purple-500 animate-pulse">
                Loading...
              </p>
            )}
            </div>
            <div className=" col-start-10 col-end-13  px-6">
            <div className=" invisible md:visible">
              <PostWidget categories={undefined} />
            </div>
          </div>
            </div>
          </div>


    </>
  );
}

export const getStaticProps: GetStaticProps = async () => {
  try {
    const fetchedPosts = await getPostsOnly();
    const fetchedTags = await getTags();
    return {
      props: { fetchedPosts, fetchedTags },
    };
  } catch (error) {
    console.error("Error fetching data:", error);
    return {
      props: { fetchedPosts: [], fetchedTags: [] },
    };
  }
};
