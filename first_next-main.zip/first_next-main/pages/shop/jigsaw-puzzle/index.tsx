import React, { useState } from 'react'
import Puzzles from '../../../components/Puzzle'
import { ProductEdge } from '../../../types';
import { getProdsByTags } from '../../../services';
import Link from 'next/link';
import { Helmet } from 'react-helmet';

const index = () => {
  const [products, setProducts] = useState<ProductEdge[] | []>([]);

  getProdsByTags("jigsaw puzzle")
      .then((newProducts) => setProducts(newProducts))
  return (
    <><Helmet>

      <title>Chess Puzzle's</title>

      <meta name="description" content="An experience chess enthusiast cannot miss. Shop chess related jigsaw puzzles." />

    </Helmet>

    <div>
        <><div>
          <img src="/goat.png" className="w-full mb-4 h-96" />
        </div>
          <div className="grid grid-cols-1 md:grid-cols-4 py-8 bg-gray-900">
            {products?.map((product, index) => (
              <div className="col-span-1 p-4 transition duration-500 rounded-md transorm hover:-translate-y-1 hover:shadow-lg hover:shadow-purple-600">
                <>
                  <Link
                    href={`/product/${product.node.slug}`}
                    className="flex justify-center"
                  >
                    <img
                      src={product.node.productImage.url}
                      className="object-cover w-40 h-40 transition duration-300 ease-in-out rounded-t-lg hover:scale-125" />
                  </Link>
                  <div className="flex flex-col items-center justify-center p-5 rounded-b-lg">
                    <p className="mb-2 text-sm font-semibold text-center">
                      {product.node.productComp}: {product.node.productTitle}
                    </p>
                    <p className="text-lg">${product.node.productPrice}</p>
                    {/* <Link href={product.node.productLink}> */}
                    <span className="inline-block w-full px-8 py-3 mx-auto mt-8 mb-6 text-lg font-medium text-center text-white transition duration-500 bg-purple-600 rounded-lg cursor-pointer transorm hover:-translate-y-1">
                      <button
                        className="snipcart-add-item"
                        data-item-id={product.node.slug}
                        data-item-name={product.node.productTitle}
                        data-item-price={product.node.productPrice}
                        data-item-url={`/product/${product.node.slug}`}
                        data-item-description="Nice Quality"
                        data-item-image={product.node.productImage.url}
                        data-item-custom1-name="Variant"
                        data-item-custom1-options={product.node.prodOptions}
                      >
                        Add to Cart
                      </button>
                    </span>
                  </div>
                </>
              </div>
            ))}

          </div></>

      </div></>
  )
}

export default index
