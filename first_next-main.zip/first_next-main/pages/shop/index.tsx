import { Helmet } from "react-helmet";
const Productss = dynamic(() => import("../../components/Nproducts"))
const PC = dynamic(() => import("../../components/ProdCat"))
const Best = dynamic(() => import("../../components/Tshirt"))
import { useState } from "react";
import dynamic from "next/dynamic";

const result: any = [];

function MyComponent({ product }: { product: any }): JSX.Element {
  const [tags, setTags] = useState("all");

  const handleTagsClick = (selectedTags: string) => {
    setTags(selectedTags.toLowerCase().trim());
  };

  return (
    <>
    <Helmet>

<title>Open Chess Shop</title>

<meta name="description" content="An experience chess enthusiast cannot miss. Shop chess related products" />

</Helmet>


      <div className="">
        {/* <div className="">
          <img src="/robot11.png" className="shop_home" />
        </div> */}
        <div className="bg-purple-600 text-center p-2 font-bold text-lg">
          Summer Sale: Use Code ILIKECHESS For 15% Off
        </div>

        <div className="min-w-full col-span-3 col-start-2 py-2 pt-12 mt-6 mb-4 sm:px-6 lg:px-8">
          <Best tags={tags} onTagsClick={handleTagsClick} />
        </div>

        <div className="grid grid-cols-1 gap-4 px-1 md:px-8 bg-gray-900 sm:grid-cols-4">
          <Productss tags={tags} />
        </div>
        <div className="min-w-full col-span-3 col-start-2 py-2 mt-20 sm:px-6 lg:px-8">
          <PC />
        </div>

      </div>
      
    </>
    
  );
}

export default MyComponent;
