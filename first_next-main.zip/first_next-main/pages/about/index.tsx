export default function about(){

    return(
        <div className="flex justify-center mt-10">
            <h1 className="semibold text-white mx-auto text center">Learn Chess :) </h1>
        </div>
    )
}