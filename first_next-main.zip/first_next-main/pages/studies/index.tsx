export default function about(){

    return(
        <div className="flex justify-center  mb-96">
            <h1 className="semibold mb-96 text-white mx-auto text center ">Coming Soon! </h1>
        </div>
    )
}