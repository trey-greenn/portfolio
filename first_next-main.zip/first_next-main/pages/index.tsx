

import { getPostsOnly} from '../services';
import { GetStaticProps} from 'next';
import dynamic from 'next/dynamic';
import Image from 'next/image'

import { Helmet } from 'react-helmet';
const Newhome = dynamic(() => import("../components/Newhome"))
const Newpc = dynamic(() => import("../components/Newpc"))
export default function Home({posts}:{posts:any}) {
  return (
    
      <>
      <Helmet>

        <title>Open Chess</title>

        <meta name="description" content="An experience chess enthusiast cannot miss. Learn, Shop, & Play Chess." />

        </Helmet>



      <div className="" >
            <h2 className="text-lg sm:text-3xl text-center mb-4"> What Do You Want to Learn?</h2>
            <div className="grid grid-cols-1 sm:grid-cols-7 bg-black  pb-4 px-6 ">
                <div className="sm:col-start-3 sm:col-end-6 bg-white rounded-lg"></div>

            </div>


                <Newhome/>
                <div className="px-32 sm:px-40 mb-20 mt-4 ">
                    <span className="text-purple-600  font-bold text-3xl sm:text-4xl hover:text-purple-600"> Articles</span>
                </div>
                <div className="grid grid-cols-10">
                  <div className="col-start-1 col-end-11 md:col-start-2 md:col-end-10">
                  {posts.map((post: { node: any; }) => <Newpc post={post} />)}


                  </div>
                </div>
          

		</div>
      
      </>

  );
};

export const getStaticProps:GetStaticProps = async () =>{
  const posts = (await getPostsOnly() || []);
  return {
    props: {posts},
  }
}



// Fetch data at build time
