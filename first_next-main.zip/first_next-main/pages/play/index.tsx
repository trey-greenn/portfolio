import Link from 'next/link'

import React from 'react'

export default function Play(){
    return(
        <>

        <h1 className="text-center col-start-3 col-end-6 pb-14 text-2xl sm:text-4xl text-purple-600 font-bold">Chess Arcade</h1>

            <div className="grid grid-cols-1 sm:grid-cols-7 mx-8">
               
                <div className="col-start-2 col-span-2   transition duration-500 transorm hover:-translate-y-1">
                    <Link className="" href="/play/jigsaw-puzzle">
                        <img
                            src="/giphy (1).gif"
                            className="rounded-l-2xl  shadow object-cover h-full md:h-52 w-fit md:w-full border-b-8 border-purple-600 " />
                    </Link>
                </div>
                <div  className="col-start-4 col-span-3 bg-black h-full   rounded-r-2xl border-b-8 border-purple-600 border-r-8 ">
                    <h2 className=" pt-4 pb-2 text-sm md:text-xl flex justify-center text-white font-bold ">Chess Jigsaw Puzzles</h2>
                            <span className="  pb-2 px-1 md:px-6 rounded-b-lg text-xs flex justify-center text-white  ">Welcome to the world of online jigsaw puzzles, where captivating images and the joy of solving come together seamlessly.</span>
                    </div>
                </div>


                <div className="grid grid-cols-1 sm:grid-cols-7 mx-8 mt-10">
               
                <div className="col-start-2 col-span-2 h-1/2   transition duration-500 transorm hover:-translate-y-1">
                    <Link className="" href="/chess-board">
                        <img
                            src="/actual chess.gif"
                            className="rounded-l-2xl  shadow object-cover h-32 md:h-52 w-fit md:w-full border-b-8 border-purple-600 " />
                    </Link>
                </div>
                <div  className="col-start-4 col-span-3 bg-black h-full  rounded-r-2xl border-b-8 border-purple-600 border-r-8 ">
                    <h2 className=" pt-4 pb-2  text-sm md:text-xl flex justify-center text-white font-bold ">Play Chess</h2>
                            <span className=" pb-2 px-1 md:px-6 rounded-b-lg text-xs flex justify-center text-white  ">Welcome to the world of online jigsaw puzzles, where captivating images and the joy of solving come together seamlessly.</span>
                    </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-7 mx-8 mt-10">
               
                <div className="col-start-2 col-span-2 h-1/2   transition duration-500 transorm hover:-translate-y-1">
                    <Link className="" href="/chess-board">
                        <img
                            src="/giphy.gif"
                            className="rounded-l-2xl  shadow object-cover h-32 md:h-52 w-full md:w-full border-b-8 border-purple-600 " />
                    </Link>
                </div>
                <div  className="col-start-4 col-span-3 bg-black h-full  rounded-r-2xl border-b-8 border-purple-600 border-r-8 ">
                    <h2 className=" pt-4 pb-2  text-sm md:text-xl flex justify-center text-white font-bold ">Meme Chess</h2>
                            <span className=" pb-2 px-1 md:px-6 rounded-b-lg text-xs flex justify-center text-white  ">Welcome to the world of online jigsaw puzzles, where captivating images and the joy of solving come together seamlessly.</span>
                    </div>
                </div>
                
                {/* <div className=" grid col-start-2 col-end-7  h-1/2   transition duration-500 transorm hover:-translate-y-1 bg-black over-hidden ">
                    <Link href="/chessboard">
                        <img
                            src="/giphy.gif"
                            className="rounded-t-lg shadow object-cover h-1/3 w-full" />
                        <span className="bg-amber-100 pt-4 pb-2  text-2xl flex justify-center text-purple-600 font-bold">Play Chess</span>
                        <span className="bg-amber-100 pt-4 pb-2 px-6 rounded-b-lg text-2xl flex justify-center text-purple-400">Experience the ultimate chess challenge with our interactive chess website. Test your skills against a formidable computer opponent and enhance your strategic prowess in thrilling online matches.</span>

                    </Link>
                </div>
                <div className="grid col-start-2 col-end-7 mb-8   transition duration-500 transorm hover:-translate-y-1 bg-black overflow-hidden">
                    <Link href="/chessboard">
                        <img
                            src="/actual chess.gif"
                            className="rounded-t-lg shadow object-cover h-3/5 w-full" />
                        <span className="bg-amber-100 pt-4 pb-2  text-2xl flex justify-center text-purple-600 font-bold">Meme Chess</span>
                        <span className="bg-amber-100 pt-4 pb-2 px-6 rounded-b-lg text-2xl flex justify-center text-purple-400 mb-4">Get ready to elevate your chess experience to a whole new level of fun and humor with our innovative web app! Introducing "Meme Chess," </span>

                    </Link>
                </div> */}


           
            </>

    )
}