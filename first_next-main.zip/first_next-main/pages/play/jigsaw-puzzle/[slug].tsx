import { GetStaticProps } from 'next';
import styled from 'styled-components';
import { getJigsaw, getJigsawDetails } from '../../../services';
import { Npuzzle } from '../../../components';



export default function Puzzle({jigsaw}:{jigsaw:any}) {

    if(!jigsaw){
        return <div/>}
        return(
          <>
          <div className="play_puzzle">
          <Npuzzle jigsaw={jigsaw} /></div></>
            
        )

}

export const getStaticProps:GetStaticProps = async({params}) =>{
    const data = (await getJigsawDetails(params!.slug))
    return {
        props: {jigsaw:data}
    }
  }
  
  export async function getStaticPaths() {
      const jigsaws = await getJigsaw();
      return {
        paths: jigsaws.map(( {node:  {slug =""} } ) => ({ params: { slug } })),
        fallback: true,
      };
    }