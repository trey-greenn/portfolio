import React,{ useState } from 'react';
import { JigsawPuzzle } from 'react-jigsaw-puzzle/lib'
import 'react-jigsaw-puzzle/lib/jigsaw-puzzle.css';
import styled from 'styled-components';
import { getJigsaw } from '../../../services';
import { GetStaticProps } from 'next';

import { Newplay, Puzzplay } from '../../../components';
import Script from 'next/script';
import { Helmet } from 'react-helmet';



export default function Puzzle({jigsaws}:{jigsaws:any}) {

  

        return(
        <>
        <Helmet>
        <Script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2274033795015131"
          crossOrigin="anonymous"/>

        <title>Play Online Jigsaws</title>

        <meta name="description" content="Unleash your strategic prowess with online chess jigsaw puzzles! Engage your mind and piece together the thrill of chess in a captivating web app. Play now" />

        </Helmet>
        
        <span className="text-center flex justify-center mb-4 sm:text-3xl text-purple-600 font-bold">Puzzle Arcade</span>
        <Newplay />
       
        <div className="mb-8 mx-8 flex justify-center mt-8">
      <span className="text-slate-300 font-bold text-3xl sm:text-3xl hover:text-purple-600">Choose Your
      <span className="text-purple-600 font-bold text-3xl sm:text-4xl hover:text-purple-600"> Puzzle</span></span>
    </div>
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 mx-8 sm:mx-24">
      {jigsaws.map((jigsaws:{ node: any; }) =><Puzzplay  jigsaws={jigsaws.node}/>)}
    </div>           
    </>
    
        )

}

const PuzzleClass = styled.div`

    width: 75%;
    height: 100%;
    border: 2px solid black;
    margin: auto;
    box-shadow: 0 5px 10px 2px rgba(0, 0, 0, 0.25);
`;

export const getStaticProps:GetStaticProps = async () =>{
    const jigsaws = (await getJigsaw() || []);
    return {
      props: {jigsaws},
    }
  }