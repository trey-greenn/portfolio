import Image from "next/image";
import Script from "next/script";

// import { Products2 } from '../../../components'
export default function shop_best_ec() {
  return (
    <>
      <Script
        strategy="lazyOnload"
        src={"https://www.googletagmanager.com/gtag/js?id=G-755JVKX9DY"}
      />
      <Script>
        {`
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());
            
              gtag('config', 'G-755JVKX9DY');
              `}
      </Script>
      <div>
        <div className="bg-black w-full h-screen p-4">
          <div className="grid grid-cols-3 gap-4 bg-black border-b mb-8 mt-36">
            <div className="grid grid-cols-7 gap-4 bg-purple-900 overflow-x-auto sm:-mx-6 lg:-mx-8 sm:w-screen">
              <div className="col-start-3 col-end-6 mb-8">
                <h2 className="mt-8 ">
                  <a
                    href="/best/electric-chessboards"
                    className="text-white hover:text-green-600 mt-8 font-bold"
                  >
                    Best Books on Chess!
                  </a>
                </h2>
              </div>
              <div className=" col-start-2 col-end-7 ">
                <table className=" table-auto border-separate  border-slate-400 border-spacing-10 ">
                  {/* <Products2/> */}
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
