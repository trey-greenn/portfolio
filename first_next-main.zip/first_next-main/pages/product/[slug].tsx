import React from 'react';
import { getProds, getProducts } from '../../services';
import { GetStaticProps } from 'next';
import dynamic from 'next/dynamic';
const ProdDetails = dynamic(() => import("../../components/ProdDetails"))
const MayLike = dynamic(() => import("../../components/MayLike"))

const productDetails = ({product}:{product:any}) => {
    if(!product){
        return <div/>}

  return (

                
            <>
            <div className="bg-purple-600 text-center p-2 font-bold text-lg">
          Summer Sale: Use Code ILIKECHESS For 15% Off
        </div>
            
            <div className="product_view">
             <ProdDetails product={product} /></div>
             <MayLike />
             </>

                
       
  )
}

export default productDetails

export const getStaticProps:GetStaticProps = async({params}) =>{
    const data = (await getProducts(params!.slug))
    return {
        props: {product:data}
    }
  }
  
  export async function getStaticPaths() {
      const products = await getProds();
      return {
        paths: products.map(( {node:  {slug =""} } ) => ({ params: { slug } })),
        fallback: true,
      };
    }
